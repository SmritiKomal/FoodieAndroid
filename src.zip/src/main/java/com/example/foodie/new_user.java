package com.example.foodie;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class new_user extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {
    private DrawerLayout drawer;
    EditText name,age,mobile,email,username,password;
    Spinner sex;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        name=(EditText)findViewById(R.id.name);
        age=(EditText)findViewById(R.id.age);
        sex=(Spinner) findViewById(R.id.sex);
        mobile=(EditText)findViewById(R.id.mobile);
        email=(EditText)findViewById(R.id.email);
        username=(EditText)findViewById(R.id.user);
        password=(EditText)findViewById(R.id.pwd);
        b=(Button)findViewById(R.id.submit);

        b.setOnClickListener(this);
    }

    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Intent i;
        switch (item.getItemId()) {
            case R.id.nav_home:
                i=new Intent(this,MainActivity.class);
                startActivity(i);
                break;

            case R.id.nav_about:
                i = new Intent(this, about.class);
                startActivity(i);
                break;
            case R.id.nav_menu:
                i = new Intent(this, menu.class);
                startActivity(i);
                break;

            case R.id.nav_deals:
                i = new Intent(this, Deals.class);
                startActivity(i);
                break;

            case R.id.nav_policies:
                i = new Intent(this, policies.class);
                startActivity(i);
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onClick(View view) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");

        myRef.setValue("Hello, World!");
    }
}