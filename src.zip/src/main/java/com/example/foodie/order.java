package com.example.foodie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.lang.reflect.Array;

public class order extends AppCompatActivity implements View.OnClickListener, NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
CheckBox cb[]=new CheckBox[60];
Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


        cb[0]=findViewById(R.id.green_salad);
        cb[1]=findViewById(R.id.boondi_raita);
        cb[2]=findViewById(R.id.fruit_salad);
        cb[3]=findViewById(R.id.mix_sprout);
        cb[4]=findViewById(R.id.tomato_soup);
        cb[5]=findViewById(R.id.sweet_corn);
        cb[6]=findViewById(R.id.veg_manchow);
        cb[7]=findViewById(R.id.hot_sour);
        cb[8]=findViewById(R.id.clear_veg);
        cb[9]=findViewById(R.id.mushroom_soup);
        cb[10]=findViewById(R.id.paneer_chilly);
        cb[11]=findViewById(R.id.veg_spring_roll);
        cb[12]=findViewById(R.id.garlic_chilly);
        cb[13]=findViewById(R.id.baby_corn_manchurian);
        cb[14]=findViewById(R.id.cheeze_burger);
        cb[15]=findViewById(R.id.french_fries);
        cb[16]=findViewById(R.id.cheeze_cutlet);
        cb[17]=findViewById(R.id.kashmiri_pulao);
        cb[18]=findViewById(R.id.veg_fried_rice);
        cb[19]=findViewById(R.id.schezwan);
        cb[20]=findViewById(R.id.jeera_rice);
        cb[21]=findViewById(R.id.steamed_rice);
        cb[22]=findViewById(R.id.mushroom_fried_rice);
        cb[23]=findViewById(R.id.tandoori_roti);
        cb[24]=findViewById(R.id.butter_roti);
        cb[25]=findViewById(R.id.plain_roti);
        cb[26]=findViewById(R.id.plain_naan);
        cb[27]=findViewById(R.id.stuffed_naan);
        cb[28]=findViewById(R.id.missi_roti);
        cb[29]=findViewById(R.id.onion_kulcha);
        cb[30]=findViewById(R.id.cheeze_kulcha);
        cb[31]=findViewById(R.id.tandoori_veg_kebab);
        cb[32]=findViewById(R.id.paneer_tikka);
        cb[33]=findViewById(R.id.tandoori_aloo);
        cb[34]=findViewById(R.id.shahi_paneer);
        cb[35]=findViewById(R.id.kadai_paneer);
        cb[36]=findViewById(R.id.palak_paneer);
        cb[37]=findViewById(R.id.gobhi_masala);
        cb[38]=findViewById(R.id.jeera_aloo);
        cb[39]=findViewById(R.id.kashmiri_kofta);
        cb[40]=findViewById(R.id.malai_kofta);
        cb[41]=findViewById(R.id.navratan_korma);
        cb[42]=findViewById(R.id.bhindi_masala);
        cb[43]=findViewById(R.id.dal_makhani);
        cb[44]=findViewById(R.id.dal_fry);
        cb[45]=findViewById(R.id.vanilla);
        cb[46]=findViewById(R.id.chocolate);
        cb[47]=findViewById(R.id.butter_scotch);
        cb[48]=findViewById(R.id.strawberry);
        cb[49]=findViewById(R.id.casatta);
        cb[50]=findViewById(R.id.kesar_pista);
        cb[51]=findViewById(R.id.cola);
        cb[52]=findViewById(R.id.sprite);
        cb[53]=findViewById(R.id.pepsi);
        cb[54]=findViewById(R.id.mountain_dew);
        cb[55]=findViewById(R.id.chocolate_milk_shake);
        cb[56]=findViewById(R.id.cold_coffee);
        cb[57]=findViewById(R.id.strawberry_shake);
        cb[58]=findViewById(R.id.tea);
        cb[59]=findViewById(R.id.coffee);

        b=findViewById(R.id.submit);
        b.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int count=0;
        String str="";
        for(int i=0;i<60;i++)
        {
            if(cb[i].isChecked())
                str=str+cb[i].getText().toString()+'\n';
        }

        Intent intent=new Intent(this,summary.class);
        intent.putExtra("hello",str);
        startActivity(intent);
    }

    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Intent i;
        switch (item.getItemId()) {
            case R.id.nav_home:
                i=new Intent(this,MainActivity.class);
                startActivity(i);
                break;

            case R.id.nav_about:
                i = new Intent(this, about.class);
                startActivity(i);
                break;
            case R.id.nav_menu:
                i = new Intent(this, menu.class);
                startActivity(i);
                break;

            case R.id.nav_deals:
                i = new Intent(this, Deals.class);
                startActivity(i);
                break;

            case R.id.nav_policies:
                i = new Intent(this, policies.class);
                startActivity(i);
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}