package com.example.foodie;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

import java.util.concurrent.TimeUnit;

public class problem extends AppCompatActivity implements View.OnClickListener, NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
EditText mob,new_pwd,otp;
Button mob_sub,new_sub,verify;
private String mVerificationId = "";
private static final String db_name="foodie_users";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problem);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        mob=findViewById(R.id.mob);
        mob_sub=findViewById(R.id.b1);

        otp=findViewById(R.id.otp);
        verify=findViewById(R.id.verify);

        new_pwd=findViewById(R.id.new_pwd);
        new_sub=findViewById(R.id.b2);

        mob_sub.setOnClickListener(this);
        verify.setOnClickListener(this);
        new_sub.setOnClickListener(this);
    }

    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Intent i;
        switch (item.getItemId()) {
            case R.id.nav_home:
                i=new Intent(this,MainActivity.class);
                startActivity(i);
                break;

            case R.id.nav_about:
                i = new Intent(this, about.class);
                startActivity(i);
                break;
            case R.id.nav_menu:
                i = new Intent(this, menu.class);
                startActivity(i);
                break;

            case R.id.nav_deals:
                i = new Intent(this, Deals.class);
                startActivity(i);
                break;

            case R.id.nav_policies:
                i = new Intent(this, policies.class);
                startActivity(i);
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onClick(View view)
    {
        if(view == mob_sub)
        {
            if(mob.getText().toString().trim().length() == 10)
                sendSMS("+91"+mob.getText().toString().trim());
            else
                Toast.makeText(this,"WRONG MOBILE NUMBER",Toast.LENGTH_SHORT).show();
        }
        else if(view == verify)
        {
            PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, otp.getText().toString());
            signInWithPhoneAuthCredential(credential);
        }
        else if(view == new_sub)
        {
            SQLiteDatabase db=SQLiteDatabase.openDatabase("foodie_users",null,0);
            ContentValues values = new ContentValues();
            values.put("name", "abc");
            values.put("username", "abc1");
            values.put("password", "abc1");
        }
    }

    private void sendSMS(String phoneNumber) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(phoneNumber,60, TimeUnit.SECONDS,  this,mCallbacks);
    }

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            signInWithPhoneAuthCredential(phoneAuthCredential);
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Toast.makeText(problem.this, "onVerificationFailed " + e.toString(), Toast.LENGTH_SHORT).show();

            if (e instanceof FirebaseAuthInvalidCredentialsException) {
                Toast.makeText(problem.this, "Invalid Request " + e.toString(), Toast.LENGTH_SHORT).show();
            } else if (e instanceof FirebaseTooManyRequestsException) {
                Toast.makeText(problem.this, "The SMS quota for the project has been exceeded " + e.toString(), Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void onCodeSent(String verificationId,
                               PhoneAuthProvider.ForceResendingToken token) {
            mVerificationId = verificationId;
            PhoneAuthProvider.ForceResendingToken mResendToken = token;
        }
    };

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        mAuth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(problem.this, "signInWithCredential:success", Toast.LENGTH_SHORT).show();
                            FirebaseUser user = task.getResult().getUser();
                            new_pwd.setVisibility(View.VISIBLE);
                            new_sub.setVisibility(View.VISIBLE);
                        } else {
                            Toast.makeText(problem.this, "signInWithCredential:failure", Toast.LENGTH_SHORT).show();
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                Toast.makeText(problem.this, "The verification code entered was invalid", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
    }

}

