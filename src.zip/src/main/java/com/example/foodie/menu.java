package com.example.foodie;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.foodie.R;
import com.google.android.material.navigation.NavigationView;

public class menu extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    Spinner saladbar,soup,appetizer,rice,tandoori,maincourse,icecream,beverages;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        saladbar=(Spinner)findViewById(R.id.saladbar);
        soup=(Spinner)findViewById(R.id.soups);
        appetizer=(Spinner)findViewById(R.id.appetizers);
        rice=(Spinner)findViewById(R.id.rice);
        tandoori=(Spinner)findViewById(R.id.tandoor_special);
        maincourse=(Spinner)findViewById(R.id.main_course);
        icecream=(Spinner)findViewById(R.id.ice_cream);
        beverages=(Spinner)findViewById(R.id.beverages);
    }

    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Intent i;
        switch (item.getItemId()) {
            case R.id.nav_home:
                i=new Intent(this,MainActivity.class);
                startActivity(i);
                break;

            case R.id.nav_about:
                i = new Intent(this, about.class);
                startActivity(i);
                break;
            case R.id.nav_menu:
                i = new Intent(this, menu.class);
                startActivity(i);
                break;

            case R.id.nav_deals:
                i = new Intent(this, Deals.class);
                startActivity(i);
                break;

            case R.id.nav_policies:
                i = new Intent(this, policies.class);
                startActivity(i);
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}