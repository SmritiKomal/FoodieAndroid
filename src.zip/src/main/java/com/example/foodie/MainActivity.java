package com.example.foodie;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.foodie.ui.home.HomeFragment;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements OnClickListener, NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;
    TextView newuser, prblm;
    EditText username, password;
    Button signin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        username = (EditText) findViewById(R.id.user);
        password = (EditText) findViewById(R.id.pwd);
        signin = (Button) findViewById(R.id.sign_in);
        newuser = (TextView) findViewById(R.id.new_user);
        prblm = (TextView) findViewById(R.id.prblm);

        signin.setOnClickListener(this);
        newuser.setOnClickListener(this);
        prblm.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == signin) {
            Intent i = new Intent(this, order.class);
            startActivity(i);
        } else if (view == newuser) {
            Intent i = new Intent(this, new_user.class);
            startActivity(i);
        }
        else if(view==prblm)
        {
            Intent i = new Intent(this,problem.class);
            startActivity(i);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Intent i;
        switch (item.getItemId()) {
            case R.id.nav_home:
                i=new Intent(this,MainActivity.class);
                startActivity(i);
                break;

            case R.id.nav_about:
                i = new Intent(this, about.class);
                startActivity(i);
                break;
            case R.id.nav_menu:
                i = new Intent(this, menu.class);
                startActivity(i);
                break;

            case R.id.nav_deals:
                i = new Intent(this, Deals.class);
                startActivity(i);
                break;

            case R.id.nav_policies:
                i = new Intent(this, policies.class);
                startActivity(i);
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}